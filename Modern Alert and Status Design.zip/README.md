
  # Modern Alert and Status Design

  This is a code bundle for Modern Alert and Status Design. The original project is available at https://www.figma.com/design/Q7rbte5V55n57r3az0CVaF/Modern-Alert-and-Status-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  