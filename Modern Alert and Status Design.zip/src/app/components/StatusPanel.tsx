import { Circle, Loader2, Check, XCircle, WifiOff, Wifi } from "lucide-react";

export type PanelStatusState = "online" | "offline" | "processing" | "idle" | "completed";

interface StatusPanelProps {
  state: PanelStatusState;
  message?: string;
  title?: string;
  showTimestamp?: boolean;
}

const stateConfig = {
  online: {
    container: "bg-green-50 border-green-200",
    icon: "text-green-600",
    text: "text-green-900",
    Icon: Wifi,
    defaultTitle: "Connected",
    defaultMessage: "System is online and running normally.",
  },
  offline: {
    container: "bg-gray-50 border-gray-200",
    icon: "text-gray-600",
    text: "text-gray-900",
    Icon: WifiOff,
    defaultTitle: "Disconnected",
    defaultMessage: "System is currently offline.",
  },
  processing: {
    container: "bg-blue-50 border-blue-200",
    icon: "text-blue-600",
    text: "text-blue-900",
    Icon: Loader2,
    defaultTitle: "Processing",
    defaultMessage: "Operation in progress...",
    animate: true,
  },
  idle: {
    container: "bg-slate-50 border-slate-200",
    icon: "text-slate-600",
    text: "text-slate-900",
    Icon: Circle,
    defaultTitle: "Idle",
    defaultMessage: "System is ready and waiting.",
  },
  completed: {
    container: "bg-emerald-50 border-emerald-200",
    icon: "text-emerald-600",
    text: "text-emerald-900",
    Icon: Check,
    defaultTitle: "Completed",
    defaultMessage: "Operation completed successfully.",
  },
};

export function StatusPanel({
  state,
  message,
  title,
  showTimestamp = false,
}: StatusPanelProps) {
  const config = stateConfig[state];
  const Icon = config.Icon;
  const displayTitle = title || config.defaultTitle;
  const displayMessage = message || config.defaultMessage;

  return (
    <div
      className={`flex items-start gap-4 p-4 rounded-lg border ${config.container}`}
      role="status"
    >
      <div className={`flex-shrink-0 ${config.icon}`}>
        <Icon
          className={`size-6 ${config.animate ? "animate-spin" : ""}`}
          aria-hidden="true"
        />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className={`font-semibold text-sm ${config.text}`}>
          {displayTitle}
        </h3>
        <p className={`text-sm mt-1 ${config.text} opacity-90`}>
          {displayMessage}
        </p>
        {showTimestamp && (
          <p className={`text-xs mt-2 ${config.text} opacity-60`}>
            {new Date().toLocaleTimeString()}
          </p>
        )}
      </div>
    </div>
  );
}
