import { AlertBanner } from "./AlertBanner";
import { StatusBadge } from "./StatusBadge";
import { StatusPanel } from "./StatusPanel";
import { ConnectionIndicator } from "./ConnectionIndicator";

export function DesignSystemShowcase() {
  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-6xl mx-auto">
        <header className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Alert & Status Design System
          </h1>
          <p className="text-lg text-slate-600">
            Component library for Flask gateway integration
          </p>
        </header>

        {/* Design Tokens */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Design Tokens
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Color Palette */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">
                Color Palette
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg bg-red-600 border border-slate-200" />
                  <div>
                    <p className="font-medium text-slate-900">Error / Danger</p>
                    <p className="text-sm text-slate-600">Red • #DC2626</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg bg-amber-500 border border-slate-200" />
                  <div>
                    <p className="font-medium text-slate-900">Warning</p>
                    <p className="text-sm text-slate-600">Amber • #F59E0B</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg bg-blue-600 border border-slate-200" />
                  <div>
                    <p className="font-medium text-slate-900">Info</p>
                    <p className="text-sm text-slate-600">Blue • #2563EB</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg bg-green-600 border border-slate-200" />
                  <div>
                    <p className="font-medium text-slate-900">Success</p>
                    <p className="text-sm text-slate-600">Green • #16A34A</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Typography */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">
                Typography
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-2xl font-bold">Heading Bold</p>
                  <p className="text-sm text-slate-600">24px / 700 weight</p>
                </div>
                <div>
                  <p className="text-lg font-semibold">Subheading Semibold</p>
                  <p className="text-sm text-slate-600">18px / 600 weight</p>
                </div>
                <div>
                  <p className="text-base">Body Regular</p>
                  <p className="text-sm text-slate-600">16px / 400 weight</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Caption Medium</p>
                  <p className="text-sm text-slate-600">14px / 500 weight</p>
                </div>
              </div>
            </div>
          </div>

          {/* Spacing */}
          <div className="mt-8">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Spacing Scale
            </h3>
            <div className="flex flex-wrap gap-4 items-end">
              <div className="text-center">
                <div className="w-2 h-2 bg-slate-900 mb-2" />
                <p className="text-xs text-slate-600">8px</p>
              </div>
              <div className="text-center">
                <div className="w-3 h-3 bg-slate-900 mb-2" />
                <p className="text-xs text-slate-600">12px</p>
              </div>
              <div className="text-center">
                <div className="w-4 h-4 bg-slate-900 mb-2" />
                <p className="text-xs text-slate-600">16px</p>
              </div>
              <div className="text-center">
                <div className="w-6 h-6 bg-slate-900 mb-2" />
                <p className="text-xs text-slate-600">24px</p>
              </div>
              <div className="text-center">
                <div className="w-8 h-8 bg-slate-900 mb-2" />
                <p className="text-xs text-slate-600">32px</p>
              </div>
            </div>
          </div>
        </section>

        {/* Alert Banners */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Alert Banners
          </h2>
          <p className="text-slate-600 mb-6">
            Inline persistent alerts with icon, text, and dismiss action.
            Padding: 16px • Border radius: 8px • Border: 1px
          </p>
          
          <div className="space-y-4">
            <AlertBanner
              type="error"
              text="Connection to detection server failed. Please check your network settings."
              onDismiss={() => {}}
            />
            <AlertBanner
              type="warning"
              text="High CPU usage detected on station server. Performance may be degraded."
              onDismiss={() => {}}
            />
            <AlertBanner
              type="info"
              text="New video feed available on control server endpoint /control/video_feed_entry."
            />
            <AlertBanner
              type="success"
              text="Detection model loaded successfully. All systems operational."
              onDismiss={() => {}}
            />
          </div>

          <div className="mt-6 bg-slate-50 p-4 rounded-lg">
            <p className="text-sm font-mono text-slate-700">
              Backend JSON: {JSON.stringify({ type: "error", text: "..." })}
            </p>
            <p className="text-sm text-slate-600 mt-2">
              Props: <code>type</code> (error|warning|info|success), <code>text</code>, <code>onDismiss?</code>
            </p>
          </div>
        </section>

        {/* Status Badges */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Status Badges
          </h2>
          <p className="text-slate-600 mb-6">
            Compact status indicators with icon and label. Three sizes available.
            Border radius: 9999px (full) • Border: 1px
          </p>

          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-700 mb-3">
                Small (sm)
              </h3>
              <div className="flex flex-wrap gap-3">
                <StatusBadge state="online" size="sm" />
                <StatusBadge state="offline" size="sm" />
                <StatusBadge state="processing" size="sm" />
                <StatusBadge state="idle" size="sm" />
                <StatusBadge state="completed" size="sm" />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-700 mb-3">
                Medium (md) – Default
              </h3>
              <div className="flex flex-wrap gap-3">
                <StatusBadge state="online" />
                <StatusBadge state="offline" />
                <StatusBadge state="processing" />
                <StatusBadge state="idle" />
                <StatusBadge state="completed" />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-700 mb-3">
                Large (lg)
              </h3>
              <div className="flex flex-wrap gap-3">
                <StatusBadge state="online" size="lg" />
                <StatusBadge state="offline" size="lg" />
                <StatusBadge state="processing" size="lg" />
                <StatusBadge state="idle" size="lg" />
                <StatusBadge state="completed" size="lg" />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-700 mb-3">
                Custom Labels
              </h3>
              <div className="flex flex-wrap gap-3">
                <StatusBadge state="online" label="Station Active" />
                <StatusBadge state="processing" label="Analyzing..." />
                <StatusBadge state="completed" label="Task Complete" />
              </div>
            </div>
          </div>

          <div className="mt-6 bg-slate-50 p-4 rounded-lg">
            <p className="text-sm font-mono text-slate-700">
              Backend JSON: {JSON.stringify({ state: "online" })}
            </p>
            <p className="text-sm text-slate-600 mt-2">
              Props: <code>state</code> (online|offline|processing|idle|completed), 
              <code>label?</code>, <code>size?</code> (sm|md|lg)
            </p>
          </div>
        </section>

        {/* Status Panels */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Status Panels
          </h2>
          <p className="text-slate-600 mb-6">
            Detailed status display with icon, title, message, and optional timestamp.
            Padding: 16px • Border radius: 8px • Border: 1px
          </p>

          <div className="space-y-4">
            <StatusPanel state="online" showTimestamp />
            <StatusPanel
              state="offline"
              message="Gateway server is not responding to health checks."
              showTimestamp
            />
            <StatusPanel
              state="processing"
              title="Running Detection Model"
              message="Processing video stream from entry camera..."
              showTimestamp
            />
            <StatusPanel
              state="idle"
              message="No active tasks. System ready for commands."
            />
            <StatusPanel
              state="completed"
              title="Batch Processing Complete"
              message="Successfully processed 247 frames. Results saved to database."
              showTimestamp
            />
          </div>

          <div className="mt-6 bg-slate-50 p-4 rounded-lg">
            <p className="text-sm font-mono text-slate-700">
              Backend JSON: {JSON.stringify({ state: "online", message: "..." })}
            </p>
            <p className="text-sm text-slate-600 mt-2">
              Props: <code>state</code>, <code>message?</code>, 
              <code>title?</code>, <code>showTimestamp?</code>
            </p>
          </div>
        </section>

        {/* Connection Indicators */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Connection Indicators
          </h2>
          <p className="text-slate-600 mb-6">
            Simple online/offline connection status. Available in full and compact modes.
          </p>

          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-700 mb-3">
                Full Mode
              </h3>
              <div className="flex flex-wrap gap-3">
                <ConnectionIndicator isConnected={true} />
                <ConnectionIndicator isConnected={false} />
                <ConnectionIndicator isConnected={true} label="Gateway Online" />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-700 mb-3">
                Compact Mode
              </h3>
              <div className="flex flex-wrap gap-3 items-center">
                <ConnectionIndicator isConnected={true} compact />
                <ConnectionIndicator isConnected={false} compact />
              </div>
            </div>
          </div>

          <div className="mt-6 bg-slate-50 p-4 rounded-lg">
            <p className="text-sm text-slate-600">
              Props: <code>isConnected</code> (boolean), 
              <code>label?</code>, <code>compact?</code>
            </p>
          </div>
        </section>

        {/* Toast Alerts */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Toast Alerts
          </h2>
          <p className="text-slate-600 mb-6">
            Non-intrusive notifications that appear in the top-right corner.
            Auto-dismiss after 3-5 seconds.
          </p>

          <div className="bg-slate-50 p-6 rounded-lg">
            <p className="text-sm font-semibold text-slate-900 mb-3">Usage:</p>
            <pre className="text-xs font-mono text-slate-700 bg-white p-4 rounded border border-slate-200 overflow-x-auto">
{`import { showAlert } from "./components/AlertToast";

// When receiving alert from backend
fetch('/alert')
  .then(r => r.json())
  .then(alert => showAlert(alert));

// Direct usage
showAlert({ 
  type: "success", 
  text: "Operation completed" 
});`}
            </pre>
          </div>

          <div className="mt-4 bg-slate-50 p-4 rounded-lg">
            <p className="text-sm font-mono text-slate-700">
              Backend JSON: {JSON.stringify({ type: "success", text: "..." })}
            </p>
            <p className="text-sm text-slate-600 mt-2">
              Function: <code>showAlert(alert)</code> where alert has 
              <code>type</code> (error|warning|info|success) and <code>text</code>
            </p>
          </div>
        </section>

        {/* Responsive Behavior */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Responsive Design
          </h2>
          
          <div className="space-y-4">
            <div className="bg-slate-50 p-4 rounded-lg">
              <h3 className="font-semibold text-slate-900 mb-2">Desktop (≥768px)</h3>
              <ul className="text-sm text-slate-700 space-y-1 list-disc list-inside">
                <li>Multi-column layouts with grid</li>
                <li>Full-width status panels and alerts</li>
                <li>Toasts positioned top-right with 16px margin</li>
              </ul>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg">
              <h3 className="font-semibold text-slate-900 mb-2">Mobile (&lt;768px)</h3>
              <ul className="text-sm text-slate-700 space-y-1 list-disc list-inside">
                <li>Single column stack layout</li>
                <li>Touch-friendly 44px minimum tap targets</li>
                <li>Toasts adapt to screen width with 8px margin</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Accessibility */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Accessibility
          </h2>
          
          <div className="space-y-3 text-sm text-slate-700">
            <div className="flex items-start gap-3">
              <span className="text-green-600 font-bold">✓</span>
              <p>Semantic HTML with proper ARIA roles (alert, status)</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-green-600 font-bold">✓</span>
              <p>Color contrast ratios meet WCAG AA standards (4.5:1 minimum)</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-green-600 font-bold">✓</span>
              <p>Icons have aria-hidden, meaningful text always present</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-green-600 font-bold">✓</span>
              <p>Keyboard navigable dismiss buttons with focus indicators</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-green-600 font-bold">✓</span>
              <p>Screen reader friendly labels and announcements</p>
            </div>
          </div>
        </section>

        {/* Backend Integration */}
        <section>
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Backend Integration
          </h2>
          
          <div className="bg-slate-50 p-6 rounded-lg space-y-4">
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">
                Endpoint: <code className="text-sm">/status</code>
              </h3>
              <pre className="text-xs font-mono text-slate-700 bg-white p-3 rounded border border-slate-200">
{`{
  "state": "online" | "offline" | "processing" | "idle" | "completed",
  "message": "Description of current state"
}`}
              </pre>
              <p className="text-sm text-slate-600 mt-2">
                Poll every 2-5 seconds. Use with StatusPanel or StatusBadge.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">
                Endpoint: <code className="text-sm">/alert</code>
              </h3>
              <pre className="text-xs font-mono text-slate-700 bg-white p-3 rounded border border-slate-200">
{`{
  "type": "error" | "warning" | "info" | "success",
  "text": "Alert message content"
}`}
              </pre>
              <p className="text-sm text-slate-600 mt-2">
                Via SSE/WebSocket or polling. Use with showAlert() or AlertBanner.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">
                Server-Sent Events (SSE)
              </h3>
              <pre className="text-xs font-mono text-slate-700 bg-white p-3 rounded border border-slate-200 overflow-x-auto">
{`const eventSource = new EventSource('/alert-stream');
eventSource.onmessage = (event) => {
  const alert = JSON.parse(event.data);
  showAlert(alert);
};`}
              </pre>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
