import { toast } from "sonner";
import { AlertCircle, AlertTriangle, Info, CheckCircle } from "lucide-react";

// Toast alert types matching backend
export type ToastAlertType = "error" | "warning" | "info" | "success";

interface AlertPayload {
  type: ToastAlertType;
  text: string;
}

// Show a toast alert - call this when you receive an alert from the backend
export function showAlert(alert: AlertPayload) {
  const { type, text } = alert;

  switch (type) {
    case "error":
      toast.error(text, {
        duration: 5000,
        icon: <AlertCircle className="size-5" />,
      });
      break;
    case "warning":
      toast.warning(text, {
        duration: 4000,
        icon: <AlertTriangle className="size-5" />,
      });
      break;
    case "success":
      toast.success(text, {
        duration: 3000,
        icon: <CheckCircle className="size-5" />,
      });
      break;
    case "info":
    default:
      toast.info(text, {
        duration: 3000,
        icon: <Info className="size-5" />,
      });
      break;
  }
}

// Example: Usage when receiving backend alert
// fetch('/alert').then(r => r.json()).then(alert => showAlert(alert));
