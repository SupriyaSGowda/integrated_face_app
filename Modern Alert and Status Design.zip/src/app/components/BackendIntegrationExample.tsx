import { useEffect, useRef } from "react";
import { showAlert } from "./AlertToast";

/**
 * Example: How to integrate with your Flask backend endpoints
 * 
 * This demonstrates the actual code patterns you'll use to connect
 * the UI components to your gateway.py endpoints.
 */

// --------------------------------------------------
// 1. POLLING STATUS ENDPOINT
// --------------------------------------------------

export function useStatusPolling(interval = 3000) {
  useEffect(() => {
    const pollStatus = async () => {
      try {
        const response = await fetch("/status");
        const data = await response.json();
        
        // data shape: { state: "online"|"offline"|"processing", message: "..." }
        // Use this with StatusPanel or StatusBadge components
        console.log("Status update:", data);
        
        // Example: Update state
        // setGatewayStatus(data);
        
      } catch (error) {
        console.error("Status polling failed:", error);
      }
    };

    pollStatus(); // Initial poll
    const timer = setInterval(pollStatus, interval);
    
    return () => clearInterval(timer);
  }, [interval]);
}

// --------------------------------------------------
// 2. SERVER-SENT EVENTS (SSE) FOR ALERTS
// --------------------------------------------------

export function useAlertSSE(endpoint = "/alert-stream") {
  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    // Create SSE connection
    eventSourceRef.current = new EventSource(endpoint);

    eventSourceRef.current.onmessage = (event) => {
      try {
        const alert = JSON.parse(event.data);
        // alert shape: { type: "error"|"warning"|"info"|"success", text: "..." }
        
        // Show toast notification
        showAlert(alert);
        
        // Optionally also add to banner list
        // setBannerAlerts(prev => [...prev, alert]);
        
      } catch (error) {
        console.error("Failed to parse SSE alert:", error);
      }
    };

    eventSourceRef.current.onerror = (error) => {
      console.error("SSE connection error:", error);
      // Optional: Show connection lost alert
      // showAlert({ type: "error", text: "Lost connection to alert stream" });
    };

    // Cleanup on unmount
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [endpoint]);
}

// --------------------------------------------------
// 3. WEBSOCKET FOR REAL-TIME UPDATES
// --------------------------------------------------

export function useWebSocketAlerts(url = "ws://localhost:5000/ws") {
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    wsRef.current = new WebSocket(url);

    wsRef.current.onopen = () => {
      console.log("WebSocket connected");
    };

    wsRef.current.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === "alert") {
          // Alert message
          showAlert(data.payload);
        } else if (data.type === "status") {
          // Status update
          console.log("Status update:", data.payload);
          // setGatewayStatus(data.payload);
        }
        
      } catch (error) {
        console.error("Failed to parse WebSocket message:", error);
      }
    };

    wsRef.current.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    wsRef.current.onclose = () => {
      console.log("WebSocket disconnected");
    };

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [url]);

  return wsRef;
}

// --------------------------------------------------
// 4. MANUAL ALERT FETCHING (ONE-TIME)
// --------------------------------------------------

export async function fetchAlert() {
  try {
    const response = await fetch("/alert");
    const alert = await response.json();
    // alert shape: { type: "error"|"warning"|"info"|"success", text: "..." }
    
    showAlert(alert);
    return alert;
    
  } catch (error) {
    console.error("Failed to fetch alert:", error);
    showAlert({ 
      type: "error", 
      text: "Failed to fetch alert from server" 
    });
  }
}

// --------------------------------------------------
// 5. COMPLETE INTEGRATION EXAMPLE COMPONENT
// --------------------------------------------------

export function CompleteBackendExample() {
  // Use the hooks
  useStatusPolling(3000); // Poll status every 3 seconds
  useAlertSSE("/alert-stream"); // Connect to SSE for alerts

  // Alternative: use WebSocket instead of SSE
  // const ws = useWebSocketAlerts("ws://localhost:5000/ws");

  // Manual trigger example
  const handleManualCheck = async () => {
    await fetchAlert();
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Backend Integration Active</h2>
      <p className="text-sm text-slate-600 mb-4">
        Status polling: Every 3 seconds<br />
        Alert stream: Server-Sent Events
      </p>
      <button
        onClick={handleManualCheck}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
      >
        Manual Alert Check
      </button>
    </div>
  );
}

// --------------------------------------------------
// USAGE IN YOUR MAIN APP:
// --------------------------------------------------

/*

import { useStatusPolling, useAlertSSE } from "./components/BackendIntegrationExample";

function App() {
  const [gatewayStatus, setGatewayStatus] = useState({
    state: "offline",
    message: "Not connected"
  });
  
  // Poll status endpoint
  useEffect(() => {
    const pollStatus = async () => {
      const response = await fetch("/status");
      const data = await response.json();
      setGatewayStatus(data);
    };
    
    const interval = setInterval(pollStatus, 3000);
    return () => clearInterval(interval);
  }, []);
  
  // Listen for SSE alerts
  useEffect(() => {
    const eventSource = new EventSource("/alert-stream");
    
    eventSource.onmessage = (event) => {
      const alert = JSON.parse(event.data);
      showAlert(alert);
    };
    
    return () => eventSource.close();
  }, []);
  
  return (
    <div>
      <Toaster position="top-right" richColors />
      
      <StatusPanel
        state={gatewayStatus.state}
        message={gatewayStatus.message}
      />
      
      {/* Rest of your app *\/}
    </div>
  );
}

*/
