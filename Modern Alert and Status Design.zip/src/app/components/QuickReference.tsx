export function QuickReference() {
  return (
    <div className="max-w-4xl mx-auto p-8 bg-white">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">
          Alert & Status System - Quick Reference
        </h1>
        <p className="text-slate-600">
          Ready-to-use components for Flask gateway integration
        </p>
      </div>

      {/* Component Overview */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-200">
          Component Overview
        </h2>

        <div className="space-y-6">
          {/* Alert Toast */}
          <div className="border border-slate-200 rounded-lg p-5">
            <h3 className="font-bold text-lg text-slate-900 mb-3">
              1. Alert Toast (showAlert)
            </h3>
            <p className="text-sm text-slate-600 mb-3">
              Non-intrusive notifications that appear temporarily in top-right corner
            </p>
            <div className="bg-slate-50 rounded p-4 mb-3">
              <p className="text-xs font-semibold text-slate-700 mb-2">Usage:</p>
              <pre className="text-xs font-mono overflow-x-auto">
{`import { showAlert } from "./components/AlertToast";

showAlert({ 
  type: "error",  // error | warning | info | success
  text: "Connection failed" 
});`}
              </pre>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <strong>Backend JSON:</strong>
                <code className="block mt-1 bg-slate-100 p-2 rounded">
                  {JSON.stringify({ type: "error", text: "..." })}
                </code>
              </div>
              <div>
                <strong>Features:</strong>
                <ul className="list-disc list-inside mt-1 text-slate-600">
                  <li>Auto-dismiss (3-5s)</li>
                  <li>Icon per type</li>
                  <li>Color-coded</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Alert Banner */}
          <div className="border border-slate-200 rounded-lg p-5">
            <h3 className="font-bold text-lg text-slate-900 mb-3">
              2. Alert Banner
            </h3>
            <p className="text-sm text-slate-600 mb-3">
              Persistent inline alerts with dismiss action
            </p>
            <div className="bg-slate-50 rounded p-4 mb-3">
              <p className="text-xs font-semibold text-slate-700 mb-2">Usage:</p>
              <pre className="text-xs font-mono overflow-x-auto">
{`import { AlertBanner } from "./components/AlertBanner";

<AlertBanner
  type="warning"  // error | warning | info | success
  text="High CPU usage detected"
  onDismiss={() => removeBanner()}
/>`}
              </pre>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <strong>Props:</strong>
                <ul className="list-disc list-inside mt-1 text-slate-600">
                  <li>type: required</li>
                  <li>text: required</li>
                  <li>onDismiss: optional</li>
                </ul>
              </div>
              <div>
                <strong>Styling:</strong>
                <ul className="list-disc list-inside mt-1 text-slate-600">
                  <li>16px padding</li>
                  <li>8px border-radius</li>
                  <li>Responsive</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Status Badge */}
          <div className="border border-slate-200 rounded-lg p-5">
            <h3 className="font-bold text-lg text-slate-900 mb-3">
              3. Status Badge
            </h3>
            <p className="text-sm text-slate-600 mb-3">
              Compact status indicator with icon and label
            </p>
            <div className="bg-slate-50 rounded p-4 mb-3">
              <p className="text-xs font-semibold text-slate-700 mb-2">Usage:</p>
              <pre className="text-xs font-mono overflow-x-auto">
{`import { StatusBadge } from "./components/StatusBadge";

<StatusBadge
  state="online"  // online | offline | processing | idle | completed
  label="Station Active"  // optional
  size="md"  // sm | md | lg
/>`}
              </pre>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <strong>States:</strong>
                <ul className="list-disc list-inside mt-1 text-slate-600">
                  <li>online → green</li>
                  <li>offline → gray</li>
                  <li>processing → blue + spinner</li>
                  <li>idle → slate</li>
                  <li>completed → emerald</li>
                </ul>
              </div>
              <div>
                <strong>Sizes:</strong>
                <ul className="list-disc list-inside mt-1 text-slate-600">
                  <li>sm: 12px text</li>
                  <li>md: 14px text (default)</li>
                  <li>lg: 16px text</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Status Panel */}
          <div className="border border-slate-200 rounded-lg p-5">
            <h3 className="font-bold text-lg text-slate-900 mb-3">
              4. Status Panel
            </h3>
            <p className="text-sm text-slate-600 mb-3">
              Detailed status display with icon, title, message, and timestamp
            </p>
            <div className="bg-slate-50 rounded p-4 mb-3">
              <p className="text-xs font-semibold text-slate-700 mb-2">Usage:</p>
              <pre className="text-xs font-mono overflow-x-auto">
{`import { StatusPanel } from "./components/StatusPanel";

<StatusPanel
  state="processing"  // online | offline | processing | idle | completed
  message="Analyzing video stream..."  // optional
  title="Detection Running"  // optional
  showTimestamp={true}  // optional
/>`}
              </pre>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <strong>Backend JSON:</strong>
                <code className="block mt-1 bg-slate-100 p-2 rounded">
                  {JSON.stringify({ state: "online", message: "..." })}
                </code>
              </div>
              <div>
                <strong>Features:</strong>
                <ul className="list-disc list-inside mt-1 text-slate-600">
                  <li>Large icon (24px)</li>
                  <li>Default messages</li>
                  <li>Optional timestamp</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Connection Indicator */}
          <div className="border border-slate-200 rounded-lg p-5">
            <h3 className="font-bold text-lg text-slate-900 mb-3">
              5. Connection Indicator
            </h3>
            <p className="text-sm text-slate-600 mb-3">
              Simple online/offline indicator
            </p>
            <div className="bg-slate-50 rounded p-4 mb-3">
              <p className="text-xs font-semibold text-slate-700 mb-2">Usage:</p>
              <pre className="text-xs font-mono overflow-x-auto">
{`import { ConnectionIndicator } from "./components/ConnectionIndicator";

<ConnectionIndicator
  isConnected={true}  // boolean
  label="Gateway Online"  // optional
  compact={false}  // optional
/>`}
              </pre>
            </div>
          </div>
        </div>
      </section>

      {/* Backend Integration */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-200">
          Backend Integration
        </h2>

        <div className="space-y-6">
          {/* Status Polling */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-5">
            <h3 className="font-bold text-slate-900 mb-3">
              📡 Status Polling Pattern
            </h3>
            <pre className="text-xs font-mono overflow-x-auto bg-white p-4 rounded border border-blue-200">
{`// Poll /status endpoint every 3 seconds
useEffect(() => {
  const pollStatus = async () => {
    const res = await fetch('/status');
    const data = await res.json();
    // data: { state: "online", message: "..." }
    setGatewayStatus(data);
  };
  
  const interval = setInterval(pollStatus, 3000);
  return () => clearInterval(interval);
}, []);

// Use in UI:
<StatusPanel
  state={gatewayStatus.state}
  message={gatewayStatus.message}
/>`}
            </pre>
          </div>

          {/* SSE Alerts */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-5">
            <h3 className="font-bold text-slate-900 mb-3">
              📨 Server-Sent Events Pattern
            </h3>
            <pre className="text-xs font-mono overflow-x-auto bg-white p-4 rounded border border-green-200">
{`// Listen to /alert-stream SSE endpoint
useEffect(() => {
  const eventSource = new EventSource('/alert-stream');
  
  eventSource.onmessage = (event) => {
    const alert = JSON.parse(event.data);
    // alert: { type: "error", text: "..." }
    showAlert(alert);
  };
  
  return () => eventSource.close();
}, []);`}
            </pre>
          </div>

          {/* WebSocket */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-5">
            <h3 className="font-bold text-slate-900 mb-3">
              🔌 WebSocket Pattern
            </h3>
            <pre className="text-xs font-mono overflow-x-auto bg-white p-4 rounded border border-purple-200">
{`// Connect to WebSocket endpoint
useEffect(() => {
  const ws = new WebSocket('ws://localhost:5000/ws');
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.type === 'alert') {
      showAlert(data.payload);
    } else if (data.type === 'status') {
      setGatewayStatus(data.payload);
    }
  };
  
  return () => ws.close();
}, []);`}
            </pre>
          </div>
        </div>
      </section>

      {/* Color Reference */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-200">
          Color Palette
        </h2>

        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <div className="w-full h-20 bg-red-600 rounded-lg mb-2" />
            <p className="font-semibold text-sm">Error</p>
            <p className="text-xs text-slate-600">#DC2626</p>
          </div>
          <div className="text-center">
            <div className="w-full h-20 bg-amber-500 rounded-lg mb-2" />
            <p className="font-semibold text-sm">Warning</p>
            <p className="text-xs text-slate-600">#F59E0B</p>
          </div>
          <div className="text-center">
            <div className="w-full h-20 bg-blue-600 rounded-lg mb-2" />
            <p className="font-semibold text-sm">Info</p>
            <p className="text-xs text-slate-600">#2563EB</p>
          </div>
          <div className="text-center">
            <div className="w-full h-20 bg-green-600 rounded-lg mb-2" />
            <p className="font-semibold text-sm">Success</p>
            <p className="text-xs text-slate-600">#16A34A</p>
          </div>
        </div>
      </section>

      {/* Accessibility */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-200">
          Accessibility Features
        </h2>

        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="font-semibold mb-2">✓ Semantic HTML</p>
            <p className="text-slate-600">Uses role="alert" and role="status"</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="font-semibold mb-2">✓ Color Contrast</p>
            <p className="text-slate-600">WCAG AA compliant (4.5:1 minimum)</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="font-semibold mb-2">✓ Keyboard Navigation</p>
            <p className="text-slate-600">Focus indicators on all interactive elements</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="font-semibold mb-2">✓ Screen Readers</p>
            <p className="text-slate-600">Icons have aria-hidden, text always present</p>
          </div>
        </div>
      </section>

      {/* File Structure */}
      <section>
        <h2 className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-200">
          File Structure
        </h2>

        <pre className="text-xs font-mono bg-slate-50 p-4 rounded-lg border border-slate-200">
{`src/app/components/
├── AlertToast.tsx              # Toast notification function
├── AlertBanner.tsx             # Inline alert banner
├── StatusBadge.tsx             # Compact status badge
├── StatusPanel.tsx             # Detailed status panel
├── ConnectionIndicator.tsx     # Online/offline indicator
├── DesignSystemShowcase.tsx    # Full component showcase
├── BackendIntegrationExample.tsx  # Integration patterns
└── QuickReference.tsx          # This reference guide`}
        </pre>
      </section>
    </div>
  );
}
