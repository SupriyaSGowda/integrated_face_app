import { Circle, Loader2, Check, XCircle } from "lucide-react";

export type StatusState = "online" | "offline" | "processing" | "idle" | "completed";

interface StatusBadgeProps {
  state: StatusState;
  label?: string;
  size?: "sm" | "md" | "lg";
}

const stateStyles = {
  online: {
    badge: "bg-green-100 text-green-800 border-green-200",
    icon: "text-green-600",
    Icon: Circle,
    defaultLabel: "Online",
  },
  offline: {
    badge: "bg-gray-100 text-gray-800 border-gray-200",
    icon: "text-gray-600",
    Icon: XCircle,
    defaultLabel: "Offline",
  },
  processing: {
    badge: "bg-blue-100 text-blue-800 border-blue-200",
    icon: "text-blue-600",
    Icon: Loader2,
    defaultLabel: "Processing",
    animate: true,
  },
  idle: {
    badge: "bg-slate-100 text-slate-800 border-slate-200",
    icon: "text-slate-600",
    Icon: Circle,
    defaultLabel: "Idle",
  },
  completed: {
    badge: "bg-emerald-100 text-emerald-800 border-emerald-200",
    icon: "text-emerald-600",
    Icon: Check,
    defaultLabel: "Completed",
  },
};

const sizeStyles = {
  sm: {
    badge: "px-2 py-0.5 text-xs gap-1",
    icon: "size-3",
  },
  md: {
    badge: "px-2.5 py-1 text-sm gap-1.5",
    icon: "size-3.5",
  },
  lg: {
    badge: "px-3 py-1.5 text-base gap-2",
    icon: "size-4",
  },
};

export function StatusBadge({ state, label, size = "md" }: StatusBadgeProps) {
  const style = stateStyles[state];
  const sizeStyle = sizeStyles[size];
  const Icon = style.Icon;
  const displayLabel = label || style.defaultLabel;

  return (
    <span
      className={`inline-flex items-center rounded-full border font-medium ${style.badge} ${sizeStyle.badge}`}
    >
      <Icon
        className={`${sizeStyle.icon} ${style.icon} ${
          style.animate ? "animate-spin" : ""
        }`}
      />
      {displayLabel}
    </span>
  );
}
