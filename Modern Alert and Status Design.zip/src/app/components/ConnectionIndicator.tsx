import { Wifi, WifiOff } from "lucide-react";

interface ConnectionIndicatorProps {
  isConnected: boolean;
  label?: string;
  compact?: boolean;
}

export function ConnectionIndicator({
  isConnected,
  label,
  compact = false,
}: ConnectionIndicatorProps) {
  if (compact) {
    return (
      <div className="flex items-center gap-1.5">
        {isConnected ? (
          <Wifi className="size-4 text-green-600" aria-label="Connected" />
        ) : (
          <WifiOff className="size-4 text-gray-400" aria-label="Disconnected" />
        )}
      </div>
    );
  }

  return (
    <div
      className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${
        isConnected
          ? "bg-green-100 text-green-800"
          : "bg-gray-100 text-gray-600"
      }`}
    >
      {isConnected ? (
        <Wifi className="size-4" aria-hidden="true" />
      ) : (
        <WifiOff className="size-4" aria-hidden="true" />
      )}
      <span className="text-sm font-medium">
        {label || (isConnected ? "Connected" : "Disconnected")}
      </span>
    </div>
  );
}
