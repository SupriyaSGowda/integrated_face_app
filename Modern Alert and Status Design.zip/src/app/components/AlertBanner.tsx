import { AlertCircle, AlertTriangle, Info, CheckCircle, X } from "lucide-react";

export type BannerAlertType = "error" | "warning" | "info" | "success";

interface AlertBannerProps {
  type: BannerAlertType;
  text: string;
  onDismiss?: () => void;
}

const alertStyles = {
  error: {
    container: "bg-red-50 border-red-200 text-red-900",
    icon: "text-red-600",
    Icon: AlertCircle,
  },
  warning: {
    container: "bg-amber-50 border-amber-200 text-amber-900",
    icon: "text-amber-600",
    Icon: AlertTriangle,
  },
  info: {
    container: "bg-blue-50 border-blue-200 text-blue-900",
    icon: "text-blue-600",
    Icon: Info,
  },
  success: {
    container: "bg-green-50 border-green-200 text-green-900",
    icon: "text-green-600",
    Icon: CheckCircle,
  },
};

export function AlertBanner({ type, text, onDismiss }: AlertBannerProps) {
  const style = alertStyles[type];
  const Icon = style.Icon;

  return (
    <div
      className={`flex items-start gap-3 p-4 rounded-lg border ${style.container}`}
      role="alert"
    >
      <Icon className={`size-5 mt-0.5 flex-shrink-0 ${style.icon}`} />
      <p className="flex-1 text-sm">{text}</p>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="flex-shrink-0 p-0.5 rounded hover:bg-black/5 transition-colors"
          aria-label="Dismiss alert"
        >
          <X className="size-4" />
        </button>
      )}
    </div>
  );
}
