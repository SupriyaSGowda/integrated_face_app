import { useState, useEffect } from "react";
import { Toaster } from "sonner";
import { showAlert } from "./components/AlertToast";
import { AlertBanner } from "./components/AlertBanner";
import { StatusBadge } from "./components/StatusBadge";
import { StatusPanel } from "./components/StatusPanel";
import { ConnectionIndicator } from "./components/ConnectionIndicator";
import { DesignSystemShowcase } from "./components/DesignSystemShowcase";
import { QuickReference } from "./components/QuickReference";

// Backend data types
interface BackendStatus {
  state: "online" | "offline" | "processing" | "idle" | "completed";
  message: string;
}

interface BackendAlert {
  type: "error" | "warning" | "info" | "success";
  text: string;
}

export default function App() {
  const [showDesignSystem, setShowDesignSystem] = useState(false);
  const [showQuickRef, setShowQuickRef] = useState(false);
  const [gatewayStatus, setGatewayStatus] = useState<BackendStatus>({
    state: "offline",
    message: "Not connected",
  });
  const [bannerAlerts, setBannerAlerts] = useState<BackendAlert[]>([]);
  const [selectedServer, setSelectedServer] = useState("station");
  const [isConnected, setIsConnected] = useState(false);

  // Simulate polling backend status endpoint every 3 seconds
  useEffect(() => {
    const pollStatus = async () => {
      try {
        // This would be: fetch('/status').then(r => r.json())
        // For demo, we'll simulate it
        const mockStatus: BackendStatus = {
          state: isConnected ? "online" : "offline",
          message: isConnected
            ? "Gateway is running normally"
            : "Gateway is not responding",
        };
        setGatewayStatus(mockStatus);
      } catch (error) {
        console.error("Status poll failed:", error);
      }
    };

    pollStatus();
    const interval = setInterval(pollStatus, 3000);
    return () => clearInterval(interval);
  }, [isConnected]);

  // Simulate receiving alerts from backend
  const simulateAlert = (type: BackendAlert["type"]) => {
    const messages = {
      error: "Connection to detection server failed",
      warning: "High CPU usage detected on station server",
      info: "New video feed available on control server",
      success: "Detection model loaded successfully",
    };

    const alert: BackendAlert = {
      type,
      text: messages[type],
    };

    // Show as toast
    showAlert(alert);

    // Also add to persistent banner list
    setBannerAlerts((prev) => [...prev, alert]);
  };

  const removeBannerAlert = (index: number) => {
    setBannerAlerts((prev) => prev.filter((_, i) => i !== index));
  };

  // Simulate server operations
  const handleStart = async (server: string) => {
    setGatewayStatus({ state: "processing", message: `Starting ${server}...` });
    showAlert({ type: "info", text: `Starting ${server} server...` });

    setTimeout(() => {
      setGatewayStatus({
        state: "online",
        message: `${server} is now running`,
      });
      setIsConnected(true);
      showAlert({ type: "success", text: `${server} started successfully` });
    }, 2000);
  };

  const handleStop = async (server: string) => {
    setGatewayStatus({ state: "processing", message: `Stopping ${server}...` });
    showAlert({ type: "info", text: `Stopping ${server} server...` });

    setTimeout(() => {
      setGatewayStatus({ state: "offline", message: `${server} is stopped` });
      setIsConnected(false);
      showAlert({ type: "info", text: `${server} stopped` });
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Toggle buttons */}
      <div className="fixed bottom-4 left-4 z-50 flex flex-col gap-2">
        <button
          onClick={() => {
            setShowDesignSystem(!showDesignSystem);
            setShowQuickRef(false);
          }}
          className="px-4 py-2 bg-slate-900 text-white rounded-lg shadow-lg hover:bg-slate-800 transition-colors text-sm font-medium"
        >
          {showDesignSystem ? "← Back to App" : "View Design System"}
        </button>
        <button
          onClick={() => {
            setShowQuickRef(!showQuickRef);
            setShowDesignSystem(false);
          }}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition-colors text-sm font-medium"
        >
          {showQuickRef ? "← Back to App" : "Quick Reference"}
        </button>
      </div>

      {showQuickRef ? (
        <QuickReference />
      ) : showDesignSystem ? (
        <DesignSystemShowcase />
      ) : (
        <>
          {/* Toast container */}
          <Toaster position="top-right" richColors />

          <div className="max-w-7xl mx-auto p-4 md:p-8">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-3xl font-bold text-slate-900">
                  Model Gateway Control
                </h1>
                <ConnectionIndicator isConnected={isConnected} />
              </div>
              <p className="text-slate-600">
                Monitor and control your Flask gateway and server fleet
              </p>
            </div>

            {/* Main Status Panel */}
            <div className="mb-6">
              <StatusPanel
                state={gatewayStatus.state}
                message={gatewayStatus.message}
                showTimestamp
              />
            </div>

            {/* Persistent Alert Banners */}
            {bannerAlerts.length > 0 && (
              <div className="space-y-3 mb-6">
                {bannerAlerts.map((alert, index) => (
                  <AlertBanner
                    key={index}
                    type={alert.type}
                    text={alert.text}
                    onDismiss={() => removeBannerAlert(index)}
                  />
                ))}
              </div>
            )}

            {/* Server Controls */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6">
              <h2 className="text-xl font-semibold text-slate-900 mb-4">
                Server Management
              </h2>

              <div className="space-y-4">
                {/* Server Selection */}
                <div className="flex flex-wrap items-center gap-4">
                  <label className="text-sm font-medium text-slate-700">
                    Select Server:
                  </label>
                  <select
                    value={selectedServer}
                    onChange={(e) => setSelectedServer(e.target.value)}
                    className="px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="station">Station</option>
                    <option value="detect">Detect</option>
                    <option value="control">Control</option>
                  </select>
                  <StatusBadge
                    state={isConnected ? "online" : "offline"}
                    label={selectedServer}
                  />
                </div>

                {/* Control Buttons */}
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => handleStart(selectedServer)}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium text-sm"
                  >
                    Start Server
                  </button>
                  <button
                    onClick={() => handleStop(selectedServer)}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium text-sm"
                  >
                    Stop Server
                  </button>
                </div>
              </div>
            </div>

            {/* Server Status Grid */}
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900">Station</h3>
                  <StatusBadge
                    state={
                      selectedServer === "station" && isConnected ? "online" : "idle"
                    }
                    size="sm"
                  />
                </div>
                <p className="text-sm text-slate-600">Video feed processing</p>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900">Detect</h3>
                  <StatusBadge
                    state={
                      selectedServer === "detect" && isConnected ? "online" : "idle"
                    }
                    size="sm"
                  />
                </div>
                <p className="text-sm text-slate-600">Object detection stream</p>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900">Control</h3>
                  <StatusBadge
                    state={
                      selectedServer === "control" && isConnected ? "online" : "idle"
                    }
                    size="sm"
                  />
                </div>
                <p className="text-sm text-slate-600">Camera control & logs</p>
              </div>
            </div>

            {/* Demo Alert Triggers */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h2 className="text-xl font-semibold text-slate-900 mb-4">
                Alert Demonstrations
              </h2>
              <p className="text-sm text-slate-600 mb-4">
                Click buttons to simulate backend alerts (toasts and banners)
              </p>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => simulateAlert("success")}
                  className="px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors font-medium text-sm border border-green-200"
                >
                  Success Alert
                </button>
                <button
                  onClick={() => simulateAlert("info")}
                  className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors font-medium text-sm border border-blue-200"
                >
                  Info Alert
                </button>
                <button
                  onClick={() => simulateAlert("warning")}
                  className="px-4 py-2 bg-amber-100 text-amber-800 rounded-lg hover:bg-amber-200 transition-colors font-medium text-sm border border-amber-200"
                >
                  Warning Alert
                </button>
                <button
                  onClick={() => simulateAlert("error")}
                  className="px-4 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors font-medium text-sm border border-red-200"
                >
                  Error Alert
                </button>
              </div>
            </div>

            {/* Integration Notes */}
            <div className="mt-8 bg-slate-50 rounded-lg p-6 border border-slate-200">
              <h3 className="font-semibold text-slate-900 mb-3">
                Backend Integration Guide
              </h3>
              <div className="space-y-2 text-sm text-slate-700">
                <p>
                  <code className="px-2 py-1 bg-slate-200 rounded text-xs">
                    /status
                  </code>{" "}
                  → Returns{" "}
                  <code className="px-2 py-1 bg-slate-200 rounded text-xs">
                    {JSON.stringify({ state: "online", message: "..." })}
                  </code>
                </p>
                <p>
                  <code className="px-2 py-1 bg-slate-200 rounded text-xs">
                    /alert
                  </code>{" "}
                  → Returns{" "}
                  <code className="px-2 py-1 bg-slate-200 rounded text-xs">
                    {JSON.stringify({ type: "error", text: "..." })}
                  </code>
                </p>
                <p className="mt-3 text-slate-600">
                  Import <strong>showAlert()</strong> to display toast notifications
                  and <strong>&lt;AlertBanner /&gt;</strong> for persistent inline alerts.
                  All components automatically style based on type/state from your backend.
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}